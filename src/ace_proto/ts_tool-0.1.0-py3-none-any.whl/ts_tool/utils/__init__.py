# Utility functions for code exploration

from ts_tool.utils.query_tester import QueryTester