"""Tree-sitter based code analysis and manipulation tool."""

__version__ = '0.1.0'